CREATE PROCEDURE [dbo].[SP_INS_IVRUSAGE]
	@IN_ICH_CALLREFID varchar(50), 
	@IN_IU_ID varchar(10), 
	@IN_IU_EII varchar(10), 
	@IN_IU_ENI varchar(10), 
	@IN_IU_EMC varchar(10), 
	@IN_IU_ORDER int
AS
BEGIN
	INSERT INTO IVR_Usage (
		ICH_CALLREFID,
		IU_ID,
		IU_EII,
		IU_ENI,
		IU_EMC,
		IU_ORDER
	)
	VALUES (
		@IN_ICH_CALLREFID,
		@IN_IU_ID,
		@IN_IU_EII,
		@IN_IU_ENI,
		@IN_IU_EMC,
		@IN_IU_ORDER
	)
END
GO