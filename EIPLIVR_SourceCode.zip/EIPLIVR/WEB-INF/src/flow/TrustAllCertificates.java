package flow;
import javax.net.ssl.X509TrustManager;
import java.security.cert.X509Certificate;

public class TrustAllCertificates implements X509TrustManager {
    @Override
    public void checkClientTrusted(X509Certificate[] chain, String authType) {
        // Do nothing - trust all clients
    }

    @Override
    public void checkServerTrusted(X509Certificate[] chain, String authType) {
        // Do nothing - trust all servers
    }

    @Override
    public X509Certificate[] getAcceptedIssuers() {
        return new X509Certificate[0]; // No accepted issuers
    }
}